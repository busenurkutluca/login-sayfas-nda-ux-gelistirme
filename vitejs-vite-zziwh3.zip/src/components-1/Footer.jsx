export default function Footer() {
  return (
    <footer>
      <p>Copyright @ 2023</p>
    </footer>
  );
}
